const initialState = {
  counter: 0
};

const reducer = (state = initialState, action) => {
  return state;
};

export default reducer;
