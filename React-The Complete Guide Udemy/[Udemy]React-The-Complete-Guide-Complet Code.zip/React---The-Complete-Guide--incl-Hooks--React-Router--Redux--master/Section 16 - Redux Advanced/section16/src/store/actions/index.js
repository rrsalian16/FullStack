export { increment, decrement, increment_val, decrement_val } from "./counter";
export { store_res, delete_res } from "./result";
