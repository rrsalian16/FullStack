import React from 'react';

const posts = props => (
  <div>
    <h1>The Posts Page</h1>
  </div>
);

export default posts;
